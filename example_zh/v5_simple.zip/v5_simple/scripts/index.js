V5.registerCard("index", function () {
    var initialize = function () {
        // Write down your initialize code at here.
    };
    return {
        initialize: initialize
    };
});
