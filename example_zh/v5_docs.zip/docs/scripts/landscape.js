V5.registerCard("landscape", function () {
    console.log("Landscape card");

    var initialize = function () {
        var card = this;
        var view = V5.View(card.node);

        view.bind("redirect", function (event) {
            var target = $(event.currentTarget);
            var hash = target.attr("href");
            page.openCard(hash.replace("#", ""));
            event.preventDefault();
        });

        view.delegateEvents({
            "click .listview a": "redirect",
        });
    };

    return {
        initialize : initialize
    };

});